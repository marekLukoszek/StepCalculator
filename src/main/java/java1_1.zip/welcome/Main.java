package welcome;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        mainMenu();
    }

    public static void mainMenu() {
        char userChoice;
        do {
            userChoice = getMainChoice();
            proceedMainChoice(userChoice);
        } while (!('1' == userChoice || '2' == userChoice));
    }

    public static char charScanner() {
        Scanner myScanner = new Scanner(System.in);
        try {
            return myScanner.nextLine().charAt(0);
        } catch (StringIndexOutOfBoundsException e) {
            return '9';
        }
    }

    public static char getMainChoice() {
        System.out.println();
        System.out.println("Proszę wybrać tryb działania aplikacji:");
        System.out.println("1 : Kalkulator");
        System.out.println("2 : Przeglądanie historii");
        System.out.println("0 : Wyjście z aplikacji");
        System.out.println("Proszę podać swój wybór:");
        return charScanner();
    }


    public static void proceedMainChoice(char userChoice) {
        if ('1' == userChoice) {
            calculator.Main.startCounting();

        } else if ('2' == userChoice) {
            historyReview.Main.startSearching();

        } else if ('0' == userChoice) {
            System.exit(0);
        } else {
            System.out.println("Niewłaściwa odpowiedź, spróbuj jeszcze raz");
        }
    }
}

