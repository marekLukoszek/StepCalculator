package calculator;

import java.util.ArrayList;
import java.util.Scanner;

public class DataReader {

    public char getOperationChoice() {
        System.out.println();
        System.out.println("Proszę wybrać rodzaj operacji");
        System.out.println("+ : dodawanie");
        System.out.println("- : odejmowanie");
        System.out.println("* : mnożenie");
        System.out.println("/ : dzielenie");
        System.out.println("0 : wyjście z programu");
        System.out.println("Proszę podać swój wybór:");
        return welcome.Main.charScanner();
    }

    public char setNumberOfArguments() {
        System.out.println();
        System.out.println("Proszę wybrać tryb wprowadzania argumentów operacji:");
        System.out.println("1 : Dwa argumenty");
        System.out.println("2 : Więcej niż dwa argumenty (np. 1+3+5+7 dla 4 argumentów)");
        System.out.println("3 : Nieokreślona liczba argumentów (aplikacja przyjmuje argumenty, aż użytkownik nie " +
                "przerwie wprowadzania)");
        System.out.println("0 : wyjście z aplikacji");
        System.out.println("Proszę podać swój wybór:");
        return welcome.Main.charScanner();
    }

    public ArrayList<Double> inputArguments(int argumentsNumber) {
        ArrayList<Double> argumentsList = new ArrayList<>();
        for (int i = 1; i <= argumentsNumber; i++) {
            System.out.println(String.format("Podaj argument nr %s", i));
            argumentsList.add(Double.parseDouble(stringScanner()));
        }
        return argumentsList;
    }


    public ArrayList<Double> inputUnknownNumberOfArguments() {
        ArrayList<Double> argumentsList = new ArrayList<>();
        int i = 1;
        String parameter;
        do {
            System.out.println(String.format("Podaj argument nr %s", i + "('X' przerywa wprowadzanie)"));
            parameter = stringScanner();
            if (!"x".equalsIgnoreCase(parameter)) {
                argumentsList.add(Double.parseDouble(parameter));
                i++;
            }
        } while (!"x".equalsIgnoreCase(parameter));
        return argumentsList;
    }

    public String stringScanner(){
        Scanner myScanner = new Scanner(System.in);
        return myScanner.nextLine();
    }
}
