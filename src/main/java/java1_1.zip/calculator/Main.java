package calculator;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Scanner;

public class Main {

    public static void startCounting() {
        System.out.println();
        System.out.println("Rozpoczynamy liczenie !!!");
        Calculator calculator = new Calculator();
        DataReader dataReader = new DataReader();
        calculator.setOperationDate(LocalDateTime.now());
        char actionChoice = dataReader.getOperationChoice();

        //ustawiam w kalkulatorze typu działania
        calculator.setOperationsType(actionChoice);

        char enteringChoice = dataReader.setNumberOfArguments();
        switch (enteringChoice) {
            //działania na 2 parametrach
            case '1': {
                calculator.setArguments(dataReader.inputArguments(2));
                System.out.println("Wynik kalkulacji to: " + calculator.calculate(calculator.getArguments()));
                break;
            }//działania na podanej liczbie argumentów
            case '2': {
                System.out.println("Podaj swoją liczbę argumentów");
                Scanner intScanner = new Scanner(System.in);
                int argumentsNumber = intScanner.nextInt();
                ArrayList<Double> argumentsList = dataReader.inputArguments(argumentsNumber);
                System.out.println("Wynik kalkulacji to: " + calculator.calculate(argumentsList));
            }// działania na dowolnej ilości parametrów
            case '3': {
                ArrayList<Double> argumentsList = dataReader.inputUnknownNumberOfArguments();
                System.out.println("Wynik kalkulacji to: " + calculator.calculate(argumentsList));
            }


            }
        }
    }

