package calculator;

import java.time.LocalDateTime;
import java.util.ArrayList;

public class Calculator {
    private LocalDateTime operationDate;
    private ArrayList<Double> arguments;
    private OperationType operationType;
    private double result;

    public void setOperationDate(LocalDateTime operationDate) {
        this.operationDate = operationDate;
    }

    public void setOperationType(OperationType operationType) {
        this.operationType = operationType;
    }

    public void setArguments(ArrayList<Double> arguments) {
        this.arguments = arguments;
    }

    public void setResult(double result) {
        this.result = result;
    }

    public LocalDateTime getOperationDate() {
        return operationDate;
    }

    public ArrayList<Double> getArguments() {
        return arguments;
    }

    public OperationType getOperationType() {
        return operationType;
    }

    public double getResult() {
        return result;
    }

    public void setOperationsType(char actionChoice) {
        if (actionChoice == '+') {
            this.setOperationType(OperationType.ADDITION);
        } else if (actionChoice == '-') {
            this.setOperationType(OperationType.SUBTRACTION);
        } else if (actionChoice == '/') {
            this.setOperationType(OperationType.DIVISION);
        } else if (actionChoice == '*') {
            this.setOperationType(OperationType.MULTIPLICATION);
        }
    }

    public Double calculate(ArrayList<Double> arrayList) {

        if (this.getOperationType().equals(OperationType.ADDITION)) {
            Double temp = 0.0;
            for (Double element : arrayList) {
                temp = temp + element;
            }
            return temp;
        } else if (this.getOperationType().equals(OperationType.SUBTRACTION)) {
            Double temp = 2 * arrayList.get(0);
            for (Double element : arrayList) {
                temp = temp - element;
            }
            return temp;
        } else if (this.getOperationType().equals(OperationType.MULTIPLICATION)) {
            Double temp = 1.0;
            for (Double element : arrayList) {
                temp = temp * element;
            }
            return temp;
        } else if (this.getOperationType().equals(OperationType.DIVISION)) {
            Double temp = arrayList.get(0) * arrayList.get(0);
            for (Double element : arrayList) {
                temp = temp / element;
            }
            return temp;
        }
        return null;
    }
}

