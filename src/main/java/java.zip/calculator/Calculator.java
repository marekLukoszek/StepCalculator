package calculator;

import java.time.LocalDateTime;
import java.util.ArrayList;

public class Calculator {
    private LocalDateTime operationDate;
    private ArrayList<Double> arguments;
    private OperationType operationType;
    private double result;

    public void setOperationDate(LocalDateTime operationDate) {
        this.operationDate = operationDate;
    }

    public void setOperationType(OperationType operationType) {
        this.operationType = operationType;
    }

    public void setArguments(ArrayList<Double> arguments) {
        this.arguments = arguments;
    }

    public void setResult(double result) {
        this.result = result;
    }

    public LocalDateTime getOperationDate() {
        return operationDate;
    }

    public ArrayList<Double> getArguments() {
        return arguments;
    }

    public OperationType getOperationType() {
        return operationType;
    }

    public double getResult() {
        return result;
    }

    public String operationChoice() {
        System.out.println();
        System.out.println("Proszę wybrać rodzaj operacji");
        System.out.println("+ : dodawanie");
        System.out.println("- : odejmowanie");
        System.out.println("* : mnożenie");
        System.out.println("// : dzielenie");
        System.out.println("0 : wyjście z programu");
        System.out.println("Proszę podać swój wybór:");
        return welcome.Main.scanner();
    }

    public String enteringArgumentsChoice() {
        System.out.println();
        System.out.println("Proszę wybrać tryb wprowadzania argumentów operacji:");
        System.out.println("1 : Dwa argumenty");
        System.out.println("2 : Więcej niż dwa argumenty (np. 1+3+5+7 dla 4 argumentów)");
        System.out.println("3 : Nieokreślona liczba argumentów (aplikacja przyjmuje argumenty, aż użytkownik nie " +
                "przerwie wprowadzania");
        System.out.println("0 : wyjście z aplikacji");
        System.out.println("Proszę podać swój wybór:");
        return welcome.Main.scanner();
    }

    public ArrayList<Double> inputArguments(int argumentsNumber) {
        ArrayList<Double> argumentsList = new ArrayList<>();
        for (int i = 1; i <= argumentsNumber; i++) {
            System.out.println(String.format("Podaj argument nr %s", i));
            argumentsList.add(Double.parseDouble(welcome.Main.scanner()));
        }
        return argumentsList;
    }

    public Double calculate(ArrayList<Double> arrayList) {

        if (this.getOperationType().equals(OperationType.ADDITION)) {
            Double temp = 0.0;
            for (Double element : arrayList) {
                temp = temp + element;
            }
            return temp;
        } else if (this.getOperationType().equals(OperationType.SUBTRACTION)) {
            Double temp = 2*arrayList.get(0);
            for (Double element : arrayList) {
                temp = temp - element;
            }
            return temp;
        } else if (this.getOperationType().equals(OperationType.MULTIPLICATION)) {
            Double temp = 1.0;
            for (Double element : arrayList) {
                temp = temp * element;
            }
            return temp;
        } else if (this.getOperationType().equals(OperationType.DIVISION)) {
            Double temp = arrayList.get(0)*arrayList.get(0);
            for (Double element : arrayList) {
                temp = temp / element;
            }
            return temp;
        }
        return null;
    }
}

