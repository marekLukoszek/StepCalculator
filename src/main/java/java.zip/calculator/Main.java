package calculator;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Scanner;

public class Main {

    public static void startCounting() {
        System.out.println();
        System.out.println("Rozpoczynamy liczenie !!!");
        Calculator calculator = new Calculator();
        calculator.setOperationDate(LocalDateTime.now());
        char actionChoice = calculator.operationChoice().charAt(0);

        //ustawiam w kalkulatorze typu działania
        if (actionChoice == '+') {
            calculator.setOperationType(OperationType.ADDITION);
        } else if (actionChoice == '-') {
            calculator.setOperationType(OperationType.SUBTRACTION);
        } else if (actionChoice == '/') {
            calculator.setOperationType(OperationType.DIVISION);
        } else if (actionChoice == '*') {
            calculator.setOperationType(OperationType.MULTIPLICATION);
        }
        char enteringChoice = calculator.enteringArgumentsChoice().charAt(0);
        switch (enteringChoice) {
            //działania na 2 parametrach
            case '1': {
                ArrayList<Double> argumentsList = calculator.inputArguments(2);
                System.out.println("Wynik kalkulacji to: " + calculator.calculate(argumentsList));
                break;
            }//działania na podanej liczbie argumentów
            case '2': {
                System.out.println("Podaj swoją liczbę argumentów");
                Scanner intScanner = new Scanner(System.in);
                int argumentsNumber = intScanner.nextInt();
                ArrayList<Double> argumentsList = calculator.inputArguments(argumentsNumber);
                System.out.println("Wynik kalkulacji to: " + calculator.calculate(argumentsList));
                }


            }
        }
    }

