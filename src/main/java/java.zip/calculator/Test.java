package calculator;

import java.util.ArrayList;
import java.util.Scanner;

public class Test {
    public static void main(String[] args) {
        System.out.println("Podaj swoją liczbę argumentów");
        Scanner intScanner = new Scanner(System.in);
        int argumentsNumber = intScanner.nextInt();
        ArrayList<Double> argumentsList = new ArrayList<>(argumentsNumber - 1);
        for (int i = 1; i <= argumentsNumber; i++) {
            System.out.println(String.format("Podaj %s argument", i));
            argumentsList.add(Double.parseDouble(welcome.Main.scanner()));
        }
    }
}