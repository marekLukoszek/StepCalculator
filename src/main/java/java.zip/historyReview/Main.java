package historyReview;

public class Main {
    public static void main(String[] args) {

    }

    public static void startSearching(){
        System.out.println("Tutaj będzie przeglądanie historii");
    }
}
