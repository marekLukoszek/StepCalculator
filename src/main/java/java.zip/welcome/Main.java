package welcome;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        mainMenu();
    }

    public static void mainMenu() {
        System.out.println();
        System.out.println("Proszę wybrać tryb działania aplikacji:");
        System.out.println("1 : Kalkulator");
        System.out.println("2 : Przeglądanie historii");
        System.out.println("0 : Wyjście z aplikacji");
        System.out.println("Proszę podać swój wybór:");
        char userChoice = scanner().charAt(0);
            if ('1' == userChoice) {
                calculator.Main.startCounting();

            } else if ('2' == userChoice) {
                historyReview.Main.startSearching();

            } else if ('0' == userChoice) {
                System.exit(0);
            } else {
                System.out.println("Niewłaściwa odpowiedź, spróbuj jeszcze raz");
            }
    }

    public static String scanner() {
        Scanner myScanner = new Scanner(System.in);
        return myScanner.nextLine();
    }

}

