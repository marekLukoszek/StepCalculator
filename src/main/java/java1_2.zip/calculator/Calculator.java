package calculator;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;
import java.time.LocalDateTime;
import java.util.ArrayList;

@XmlAccessorType(XmlAccessType.FIELD)
public class Calculator {
    @XmlJavaTypeAdapter(LocalDateTimeAdapter.class)
    private LocalDateTime operationDate;
    private ArrayList<Double> arguments;
    private OperationType operationType;
    private double result;

    public void setOperationDate(LocalDateTime operationDate) {
        this.operationDate = operationDate;
    }

    public void setOperationType(OperationType operationType) {
        this.operationType = operationType;
    }

    public void setArguments(ArrayList<Double> arguments) {
        this.arguments = arguments;
    }

    public void setResult(double result) {
        this.result = result;
    }

    public LocalDateTime getOperationDate() {
        return operationDate;
    }

    public ArrayList<Double> getArguments() {
        return arguments;
    }

    public OperationType getOperationType() {
        return operationType;
    }

    public double getResult() {
        return result;
    }

    public void setOperationsType(char actionChoice) {
        if (actionChoice == '+') {
            this.setOperationType(OperationType.ADDITION);
        } else if (actionChoice == '-') {
            this.setOperationType(OperationType.SUBTRACTION);
        } else if (actionChoice == '/') {
            this.setOperationType(OperationType.DIVISION);
        } else if (actionChoice == '*') {
            this.setOperationType(OperationType.MULTIPLICATION);
        }
    }

    public Double calculate(ArrayList<Double> arrayList) {
        int counter = 1;
        if (this.getOperationType().equals(OperationType.ADDITION)) {
            Double temp = arrayList.get(0);
            for (int i = 1; i < arrayList.size(); i++) {
                temp += arrayList.get(i);
            }
            counter++;
            return temp;
        } else if (this.getOperationType().equals(OperationType.SUBTRACTION)) {
            Double temp = arrayList.get(0);
            for (int i = 1; i < arrayList.size(); i++) {
                temp -= arrayList.get(i);
            }
            return temp;
        } else if (this.getOperationType().equals(OperationType.MULTIPLICATION)) {
            Double temp = arrayList.get(0);
            for (int i = 1; i < arrayList.size(); i++) {
                temp = temp * arrayList.get(i);
            }
            return temp;
        } else if (this.getOperationType().equals(OperationType.DIVISION)) {
            Double temp = arrayList.get(0);
            for (int i = 1; i < arrayList.size(); i++) {
                temp = temp / arrayList.get(i);
            }
            return temp;
        }
        return null;
    }
}

