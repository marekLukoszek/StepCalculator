package historyReview;

public class Main {

    public static void startSearching(){
        System.out.println("Tutaj będzie przeglądanie historii");
    }
}
