package resultsWriter;

import calculator.Calculator;
import calculator.Calculators;

import javax.xml.bind.JAXB;
import java.io.File;
import java.util.ArrayList;

public class Main {
    public static ArrayList<Calculator> bufferedCalculators = new ArrayList<>();
    public static final String pathToArchiveXml = "E:/PROGRAMOWANIE/Step/Calculator/historicalData.xml";

    public static void startWriting(Calculator calculator) {
        bufferedCalculators.add(calculator);
    }

    public static void updateXml() {
        Calculators calculators = readFromXml();
        ArrayList<Calculator> list = calculators.getCalculatorsArrayList();
        list.addAll(0, bufferedCalculators);
        calculators.setCalculatorsArrayList(list);
        writeResultsToXML(calculators);
    }

    public static Calculators readFromXml() {
        return JAXB.unmarshal(new File(pathToArchiveXml), Calculators.class);
    }

    public static void writeResultsToXML(Calculators calculators) {
        JAXB.marshal(calculators, new File(pathToArchiveXml));
        bufferedCalculators.clear();
    }
}