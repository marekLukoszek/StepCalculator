package historyReview;

import calculator.Calculator;
import calculator.Calculators;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;

import static dataReader.DataReader.charScanner;
import static historyReview.EnteringDates.enterEndDate;
import static historyReview.EnteringDates.enterStartDate;
import static resultsWriter.Main.readFromXml;


public class Main {
    private static final DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd.MM.yyyy HH:mm:ss");

    public static void startSearching() {
        char chosenReviewModel = chooseReviewModel();
        switch (chosenReviewModel) {
            case '1': {
                showFullHistory();
                break;
            }
            case '2': {
                showHistoryFromStartDate();
                break;
            }
            case '3': {
                showHistoryToEndDate();
                break;
            }
            case '4': {
                showHistoryBetweenDates();
                break;
            }
            case '0': {
                System.exit(0);
            }
        }
    }

    public static char chooseReviewModel() {
        System.out.println("Wybierz tryb przeglądania historii: ");
        System.out.println("1: Pełna historia");
        System.out.println("2: Historia od zadanej daty do teraz");
        System.out.println("3: Historia od początku do zadanej daty");
        System.out.println("4: Historia pomiędzy dwoma zadanymi datami");
        System.out.println("0: Wyjście z aplikacji");
        System.out.println("Proszę podać swój wybór");
        return charScanner();
    }

    public static void showFullHistory() {
        System.out.println("Znalezione operacje: ");
        Calculators calculatorsViewer = readFromXml();
        assert calculatorsViewer != null;
        for (Calculator element : calculatorsViewer.getCalculatorsArrayList()) {
            System.out.println(element.toString());
        }
    }

    public static void showHistoryFromStartDate() {
        Calculators calculatorsViewer = readFromXml();
        LocalDateTime startDate = LocalDateTime.now().plusDays(1);
        do {
            try {
                startDate = LocalDateTime.parse(enterStartDate(), formatter);
            } catch (DateTimeParseException e) {
                System.out.println("Podaj poprawny format daty !!!");
            }
        }
        while (startDate.isAfter(LocalDateTime.now()));

        System.out.println("Znalezione operacje: ");
            assert calculatorsViewer != null;
            for (Calculator element : calculatorsViewer.getCalculatorsArrayList()) {
                if (startDate.isBefore(element.getOperationDate())) {
                    System.out.println(element.toString());
                }
            }
        }

    public static void showHistoryToEndDate() {
        Calculators calculatorsViewer = readFromXml();
        LocalDateTime endDate = LocalDateTime.now().plusDays(1);
        do {
            try {
                endDate = LocalDateTime.parse(enterEndDate(), formatter);
            } catch (DateTimeParseException e) {
                System.out.println("Podaj poprawny format daty !!!");
            }
        }
        while (endDate.isAfter(LocalDateTime.now()));

        System.out.println("Znalezione operacje: ");
        assert calculatorsViewer != null;
        for (Calculator element : calculatorsViewer.getCalculatorsArrayList()) {
            if (endDate.isAfter(element.getOperationDate())) {
                System.out.println(element.toString());
            }
        }
    }

    public static void showHistoryBetweenDates() {
        Calculators calculatorsViewer = readFromXml();
        LocalDateTime startDate = LocalDateTime.parse(enterStartDate(), formatter);
        LocalDateTime endDate = LocalDateTime.parse(enterEndDate(), formatter);
        System.out.println("Znalezione operacje: ");
        assert calculatorsViewer != null;
        for (Calculator element : calculatorsViewer.getCalculatorsArrayList()) {
            if (startDate.isBefore(element.getOperationDate()) && endDate.isAfter(element.getOperationDate())) {
                System.out.println(element.toString());


            }
        }
    }
}


