package historyReview;

import static dataReader.DataReader.stringScanner;

public class EnteringDates {

    public static String enterStartDate() {
        System.out.println("Proszę wprowadzić datę początkową");
        System.out.println("Data powinna być wprowadzona w formacie 'DD.MM.YYYY hh:mm:ss', gdzie");
        System.out.println("DD - dzień, MM - miesiąc, YYYY - rok");
        System.out.println("hh - godzina, mm - minuty, ss - sekundy");
        System.out.println("Proszę podać swój wybór:");
        return stringScanner();
    }

    public static String enterEndDate() {
        System.out.println("Proszę wprowadzić datę końcową");
        System.out.println("Data powinna być wprowadzona w formacie 'DD.MM.YYYY hh:mm:ss', gdzie");
        System.out.println("DD - dzień, MM - miesiąc, YYYY - rok");
        System.out.println("hh - godzina, mm - minuty, ss - sekundy");
        System.out.println("Proszę podać swój wybór:");
        return stringScanner();
    }
}
