package historyReview;

import static dataReader.DataReader.stringScanner;

public class EnteringDates {

    public static String enterDate(String startOrEnd) {
        System.out.println(String.format("Proszę wprowadzić datę %s", startOrEnd));
        System.out.println("Data powinna być wprowadzona w formacie 'DD.MM.YYYY hh:mm:ss', gdzie");
        System.out.println("DD - dzień, MM - miesiąc, YYYY - rok");
        System.out.println("hh - godzina, mm - minuty, ss - sekundy");
        System.out.println("Proszę podać swój wybór:");
        return stringScanner();
    }
}
