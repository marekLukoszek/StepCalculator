package calculator;

import java.util.ArrayList;

public class Calculators {
    private ArrayList<Calculator> calculatorArrayList;

    public Calculators() {
    }

    public Calculators(ArrayList<Calculator> calculatorArrayList) {
        this.calculatorArrayList = calculatorArrayList;
    }

    public ArrayList<Calculator> getCalculatorsArrayList() {
        return calculatorArrayList;
    }

    public void setCalculatorsArrayList(ArrayList<Calculator> calculatorArrayList) {
        this.calculatorArrayList = calculatorArrayList;
    }
}
