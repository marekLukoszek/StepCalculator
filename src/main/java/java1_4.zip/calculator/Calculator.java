package calculator;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@XmlAccessorType(XmlAccessType.FIELD)
public class Calculator {
    @XmlJavaTypeAdapter(LocalDateTimeAdapter.class)
    private LocalDateTime operationDate;
    private List<Double> arguments;
    private OperationType operationType;
    private double result;

    public Calculator(LocalDateTime operationDate, ArrayList<Double> arguments, OperationType operationType, double result) {
        this.operationDate = operationDate;
        this.arguments = arguments;
        this.operationType = operationType;
        this.result = result;
    }

    public Calculator() {
    }

    public void setOperationDate(LocalDateTime operationDate) {
        this.operationDate = operationDate;
    }

    public void setOperationType(OperationType operationType) {
        this.operationType = operationType;
    }

    public void setArguments(List<Double> arguments) {
        this.arguments = arguments;
    }

    public void setResult(double result) {
        this.result = result;
    }

    public LocalDateTime getOperationDate() {
        return operationDate;
    }

    public List<Double> getArguments() {
        return arguments;
    }

    public OperationType getOperationType() {
        return operationType;
    }

    public double getResult() {
        return result;
    }

    public void setOperationsType(char actionChoice) {
        if (actionChoice == '+') {
            this.setOperationType(OperationType.ADDITION);
        } else if (actionChoice == '-') {
            this.setOperationType(OperationType.SUBTRACTION);
        } else if (actionChoice == '/') {
            this.setOperationType(OperationType.DIVISION);
        } else if (actionChoice == '*') {
            this.setOperationType(OperationType.MULTIPLICATION);
        }
    }

    public Double calculate(List<Double> arrayList) {
        Double temp = arrayList.get(0);
        if (this.getOperationType().equals(OperationType.ADDITION)) {
            for (int i = 1; i < arrayList.size(); i++) {
                temp += arrayList.get(i);
            }
        } else if (this.getOperationType().equals(OperationType.SUBTRACTION)) {
            for (int i = 1; i < arrayList.size(); i++) {
                temp -= arrayList.get(i);
            }
        } else if (this.getOperationType().equals(OperationType.MULTIPLICATION)) {
            for (int i = 1; i < arrayList.size(); i++) {
                temp = temp * arrayList.get(i);
            }
        } else if (this.getOperationType().equals(OperationType.DIVISION)) {
            for (int i = 1; i < arrayList.size(); i++) {
                temp = temp / arrayList.get(i);
            }
        }
        return temp;
    }

    public String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        for (int i = 0; i <= getArguments().size() - 1; i++) {
            stringBuilder.append(" ");
            stringBuilder.append((getArguments().get(i).toString()));
            stringBuilder.append(" ");
            stringBuilder.append(getOperationType().getSign());
        }
        stringBuilder.deleteCharAt(stringBuilder.length()-1);
        return "Data operacji: " + getOperationDate() + " Operacja:" + stringBuilder + "= " + getResult();

    }
}


