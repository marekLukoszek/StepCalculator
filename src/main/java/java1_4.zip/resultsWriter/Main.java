package resultsWriter;

import calculator.Calculator;
import calculator.Calculators;
import calculator.OperationType;

import javax.xml.bind.DataBindingException;
import javax.xml.bind.JAXB;
import java.io.File;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import static resultsWriter.RecordLog.*;


public class Main {
    public static ArrayList<Calculator> bufferedCalculators = new ArrayList<>();
    public static final String pathToArchiveXml = "E:/PROGRAMOWANIE/Step/Calculator/historicalData.xml";

    public static void startWriting(Calculator calculator) {
        bufferedCalculators.add(0, calculator);
    }

    public static void updateXml() {

        //aktualizuje recordFile
        logFileExistCheck();
        List<String> logFileLines = readLogFile();
        List<String> newLogFileLines = updateLogFileLinesArray(bufferedCalculators, logFileLines);
        writeNewLogFile(newLogFileLines);
        //aktualizuję xml jeśli w buforze jest nowa kalkulacja
        if (bufferedCalculators.size() != 0) {
            Calculators calculators = readFromXml();
            ArrayList<Calculator> list;
            if (calculators != null && calculators.getCalculatorsArrayList() != null) {
                list = calculators.getCalculatorsArrayList();
                list.addAll(0, bufferedCalculators);
                calculators.setCalculatorsArrayList(list);
            } else {
                calculators = new Calculators();
                calculators.setCalculatorsArrayList(bufferedCalculators);
            }

            writeResultsToXML(calculators);
            bufferedCalculators.clear();

        }
    }

    public static Calculators readFromXml() {
        try {
            return JAXB.unmarshal(new File(pathToArchiveXml), Calculators.class);
        } catch (DataBindingException e) {
            return null;
        }
    }

    public static void writeResultsToXML(Calculators calculators) {
        JAXB.marshal(calculators, new File(pathToArchiveXml));
    }

}
